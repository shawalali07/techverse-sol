import { authApi } from '../../../configurations/AxiosIntercenptor';
import { setToken } from '../../slices/authSlice';
import { authRoutes } from '../../../routes/serverRoutes';
import { browserRoutes } from '../../../routes/browserRoutes';
import fail from '../../../utils/fail';
import success from '../../../utils/success';

const signup = (formValue, navigate) => async (dispatch) => {
  try {
    const { data } = await authApi.post(authRoutes.SIGNUP, formValue);
    dispatch(setToken({ email: data?.data?.data?.email }));
    success('Account created');
    navigate(browserRoutes.SIGNIN);
  } catch (error) {
    fail(error.response?.data?.message);
  }
};

export { signup };
