import { api } from '../../../configurations/AxiosIntercenptor';
import { authRoutes } from '../../../routes/serverRoutes';
import {
  failQuestionsData,
  failSpecificQuestionsData,
  setQuestionsData,
  setSpecificUserQuestions,
  startQuestionsData,
  startSpecificQuestions,
} from '../../slices/questionSlice';
import success from '../../../utils/success';

const askQuestion = async (formData, setLoading) => {
  setLoading(true);
  try {
    const { data } = await api.post(authRoutes.ASK_QUESTION, formData);
    success('Your question is submitted');
    setLoading(false);
  } catch (error) {
    setLoading(false);
    console.log(error?.response?.data?.message);
  }
};

const getQuestions = () => async (dispatch) => {
  dispatch(startQuestionsData());

  try {
    const { data } = await api.get(authRoutes.GET_QUESTIONS);
    dispatch(setQuestionsData(data));
  } catch (error) {
    dispatch(failQuestionsData());
    console.log(error?.response);
  }
};

const getSpecificUserQuestions = () => async (dispatch) => {
  dispatch(startSpecificQuestions());
  try {
    const { data } = await api.get(authRoutes.MY_QUESTIONS);
    dispatch(setSpecificUserQuestions(data));
  } catch (error) {
    dispatch(failSpecificQuestionsData());
    console.log(error?.response);
  }
};

export { askQuestion, getQuestions, getSpecificUserQuestions };
