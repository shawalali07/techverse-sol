import { api } from '../../../configurations/AxiosIntercenptor';
import { authRoutes } from '../../../routes/serverRoutes';
import success from '../../../utils/success';
import { setUpdatedProfile } from '../../slices/authSlice';
export const updateProfile = (formData, setLoading) => async (dispatch) => {
  setLoading(true);
  try {
    const { data } = await api.put(authRoutes.UPDATE_PROFILE, formData);
    dispatch(setUpdatedProfile(data));
    success('Profile has been updated...');
    setLoading(false);
  } catch (error) {
    setLoading(false);
  }
};
