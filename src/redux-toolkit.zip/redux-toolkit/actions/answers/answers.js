import { api } from '../../../configurations/AxiosIntercenptor';
import { authRoutes } from '../../../routes/serverRoutes';
import success from '../../../utils/success';
import { setAllAnswersData, setAnswersData } from '../../slices/answerSlice';

const submitAnswer = (formData, setLoading) => async (dispatch) => {
  setLoading(true);
  try {
    const { data } = await api.post(authRoutes.SUBMIT_ANSWER, formData);
    success('Your answer is submitted');

    setLoading(false);
  } catch (error) {
    setLoading(false);
    console.log(error?.response?.data?.message);
  }
};

const getAnswersById = (id) => async (dispatch) => {
  try {
    const { data } = await api.get(`${authRoutes.GET_ANSWERS}/${id}`);
    dispatch(setAnswersData(data));
  } catch (error) {
    console.log(error);
  }
};

const getAnswers = () => async (dispatch) => {
  try {
    const { data } = await api.get(authRoutes.GET_ANSWERS);
    dispatch(setAllAnswersData(data));
  } catch (error) {
    console.log(error);
  }
};

export { submitAnswer, getAnswersById, getAnswers };
