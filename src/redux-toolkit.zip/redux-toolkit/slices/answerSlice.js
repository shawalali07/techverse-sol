import { createSlice } from '@reduxjs/toolkit';

export const answer = createSlice({
  name: 'answer',
  initialState: {
    answersData: [],
    allAnswersData: [],
  },
  reducers: {
    setAnswersData: (state, action) => {
      state.answersData = action.payload;
    },
    setAllAnswersData: (state, action) => {
      state.allAnswersData = action.payload;
    },
  },
});

export const { setAnswersData, setAllAnswersData } = answer.actions;

export default answer.reducer;
