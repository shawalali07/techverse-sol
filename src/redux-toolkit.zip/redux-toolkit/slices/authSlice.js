import { createSlice } from '@reduxjs/toolkit';

export const authSlice = createSlice({
  name: 'authSlice',
  initialState: {
    token: '',
    fullName: '',
    email: '',
  },
  reducers: {
    setToken: (state, action) => {
      state.token = action.payload.token;
      state.email = action.payload.email;
      state.fullName = action.payload.fullName;
    },
    destroyToken: (state) => {
      state.token = '';
      state.fullName = '';
      state.email = '';
    },
    setUpdatedProfile: (state, action) => {
      state.email = action.payload.email;
      state.fullName = action.payload.name;
    },
  },
});

export const { setToken, destroyToken, setUpdatedProfile } = authSlice.actions;

export default authSlice.reducer;
